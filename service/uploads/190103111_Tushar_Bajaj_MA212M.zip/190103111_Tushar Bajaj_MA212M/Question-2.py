import math

#Binomial Distr ibution
trials_binomial = 15
n_binomial = 20
p_binomial = 0.3
def run_binom(trials, n, p):
    probab = []
    probab_sum = 0
    for i in range(trials+1):
        C = math.factorial(n)/(math.factorial(i)*math.factorial(n-i))
        probab.append(C*pow(p,i)*pow(1-p,n-i))
        probab_sum+=C*pow(p,i)*pow(1-p,n-i)
    return probab, probab_sum

# Run the function
binomial_distribution, binomial_distribution_sum = run_binom(trials_binomial, n_binomial, p_binomial)

print("Binomial Probability Distribution:",binomial_distribution)
print("Binomial Cumulative Probability Distribution:",binomial_distribution_sum)

#Poison Distribution
trials_poison = 15
lambda_poison = 3
def run_poison(trials, lambda_poison):
    probab = []
    probab_sum = 0
    for i in range(trials+1):
        probab.append(pow(lambda_poison,i)*math.exp(-1*lambda_poison)/math.factorial(i))
        probab_sum += pow(lambda_poison,i)*math.exp(-1*lambda_poison)/math.factorial(i)
    return probab, probab_sum

# Run the function
poison_distribution, poison_distribution_sum = run_poison(trials_poison, lambda_poison)
print("Poison Probability Distribution:",poison_distribution)
print("Poison Cumulative Probability Distribution:",poison_distribution_sum)
