A_money = 12
B_money = 38
p = 0.4
no_of_trials = 1000
q = 1 - p 

P_1 = (1-(q/p))/(1-pow((q/p),A_money+B_money))

def recurse(i):
    if i==0 :
        return P_1
    
    return recurse(i-1) + pow(1.5,i)*P_1

print("The Probability of A wining is:",recurse(A_money-1))