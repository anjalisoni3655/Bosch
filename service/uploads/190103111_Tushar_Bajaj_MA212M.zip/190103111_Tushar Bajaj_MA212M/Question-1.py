from scipy.special import gamma, gammaln
import numpy



class Multinomial(object):
    def __init__(self, p, rso=numpy.random):
        if not numpy.isclose(numpy.sum(p), 1.0):
            raise ValueError("event probabilities do not sum to 1")

        self.p = p
        self.rso = rso
        self.logp = numpy.log(self.p)

    def sample(self, n):
        x = self.rso.multinomial(n, self.p)
        return x

    def log_pmf(self, x):
        n = numpy.sum(x)

        log_n_factorial = gammaln(n + 1)


        sum_log_xi_factorial = numpy.sum(gammaln(x + 1))
        log_pi_xi = self.logp * x
        log_pi_xi[x == 0] = 0
        sum_log_pi_xi = numpy.sum(log_pi_xi)


        log_pmf = log_n_factorial - sum_log_xi_factorial + sum_log_pi_xi
        return log_pmf


dist = Multinomial(numpy.array([0.2,0.4,0.3,0.1]))
for i in range(10):
    print(dist.sample(20))


print('\n\nChecking with inbuilt library')
print(numpy.random.multinomial(20,[0.2,0.4,0.3,0.1],size=10))
