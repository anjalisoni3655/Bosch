num_boxes = 50
no_of_coupons = 10


def probab_calculator(n, k):
    if k == 1:
        return (1/no_of_coupons)**n
    elif n == 1:
        return 0
    else:
        return probab_calculator(n - 1, k)*(k/no_of_coupons) + probab_calculator(n - 1, k - 1)*(k/no_of_coupons)


print("Chances of getting all the coupons:",probab_calculator(num_boxes, no_of_coupons))